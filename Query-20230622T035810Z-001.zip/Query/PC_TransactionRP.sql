declare @shopcode0 varchar(50) = 'PC3002';
declare @fromterminal varchar(50) = '01';
declare @toterminal varchar(50) = '99';
declare @fromdate varchar(50) = '2022-07-01';
declare @todate varchar(50) = '2022-07-31';
declare @fromtime varchar(50) = '00:00';
declare @totime varchar(50) = '23:59';
declare @userid varchar(50) = '9999999';
declare @catecode0 varchar(50) = '';


select bh.* into #tmp_billhdrtb
from billhdrtb bh (nolock)

inner join posshoptb p (nolock) on p.shopcode = bh.shopcode

inner join
(
select p.shopcode
from posshoptb p (nolock)
inner join extstructuretb ext (nolock) on p.shgrpcode = ext.groupcode
where ext.recordtype = 'user' and ext.usrcode = '9999999'

union

select p.shopcode
from posshoptb p (nolock)
inner join extstructuretb ext (nolock) on p.shclscode = ext.classcode
where ext.recordtype = 'user' and ext.usrcode = '9999999'

union

select p.shopcode
from posshoptb p (nolock)
inner join extstructuretb ext (nolock) on p.shtypcode = ext.typecode
where ext.recordtype = 'user' and ext.usrcode = '9999999'

union

select p.shopcode
from posshoptb p (nolock)
inner join extstructuretb ext (nolock) on p.shopcode = ext.shopcode
where ext.recordtype = 'user' and ext.usrcode = '9999999'
) us on us.shopcode = p.shopcode


WHERE bh.ShopCode IN(@shopcode0) AND (bh.TerminalNo BETWEEN @fromterminal AND @toterminal) AND (bh.EntDate BETWEEN @fromdate AND @todate) AND (LEFT(bh.BillTime,5) BETWEEN @fromtime AND @totime) 

select bp.shopcode,bp.entdate,bp.TerminalNo,bp.billno,bp.tendtype,bp.tendcode,bp.cardname,bp.tendamt into #tmp_billpaytbx
from #tmp_billhdrtb bh (nolock)
inner join billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
where bp.[sequence] >= 5000 AND bp.[sequence] < 8000 and bp.TendCode <> 'CHG' and ((bp.TendCode <> 'DRAR' and bp.TendAmt <> 0) or bp.TendCode = 'DRAR' and bp.TendAmt <> 0)

select bp.shopcode,bp.entdate,bp.TerminalNo,bp.billno,bp.tendtype,bp.tendcode,bp.cardname,bp.tendamt into #tmp_billpaytbz
from #tmp_billhdrtb bh (nolock)
inner join billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
where bp.TendCode = 'CHG'

select bh.shopcode,bh.entdate,bh.TerminalNo,bh.BillNo,bh.tendtype,bh.tendcode,bh.cardname
,sum(case when bh.tendcode+bh.Tendtype = 'CSHCSH' then bh.tendamt - bp.tendamt else bh.tendamt end) as tendamt into #tmp_billpaytb
from #tmp_billpaytbx bh (nolock)
left join #tmp_billpaytbz bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
group by bh.shopcode,bh.entdate,bh.TerminalNo,bh.BillNo,bh.tendtype,bh.tendcode,bh.cardname

select td.ShopCode,td.EntDate,td.TerminalNo,td.BillNo,i.catcode0,sum(bd.NetAmt) as NetAmt
,sum(case when bd.itemcode = bd.subcode then bd.ActQTY else 0 end) as Qty into #tmp_tenderx 
from #tmp_billhdrtb td (nolock)
inner join BillDtlTB bd (nolock) on td.shopcode = bd.ShopCode and td.EntDate = bd.EntDate and td.TerminalNo = bd.TerminalNo and td.BillNo = bd.BillNo
inner join itmmastb i (nolock) on i.itemcode = bd.subcode  
group by td.ShopCode,td.EntDate,td.TerminalNo,td.BillNo,i.catcode0

select bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo,sum(bh.qty) as qty,bp.tendtype,bp.tendcode,bp.cardname,bp.TendAmt 
,row_number() OVER(partition BY bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo order by bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo) AS Row  into #tmp_tender 
from #tmp_tenderx bh (nolock)
left outer join #tmp_billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
group by bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo,bp.tendtype,bp.tendcode,bp.cardname,bp.TendAmt

SELECT isnull(SUM(x.[Bill Count]),0) AS [Bill Count],  isnull(sum(x.[Cust Count]),0) as [Cust Count],isnull(sum(x.Qty),0) as Qty,isnull(sum(x.[Gross Sales]),0) as [Gross Sales]
,isnull(sum(x.[Discount]),0) as [Discount],isnull(sum(x.[Base Sales]),0) as [Base Sales],isnull(sum(x.Vat),0) as Vat,isnull(sum(x.[Net Sales]),0) as [Net Sales]
,isnull(sum(x.[Service Charge]),0) as [Service Charge],isnull(sum(x.[Base Service Charge]),0) as [Base Service Charge],isnull(sum(x.[Vat Service Charge]),0) as [Vat Service Charge]
,isnull(sum(x.[Net Total]),0) as [Net Total] ,ISNULL(SUM(x.[CASH]),0) AS [CASH],ISNULL(SUM(x.[TENDER001]),0) AS [TENDER001],ISNULL(SUM(x.[TENDER002]),0) AS [TENDER002],isnull(sum(x.totalpay),0) AS [Total Payment],isnull(sum(x.TotalOCR),0) AS [Total OCR]
FROM (SELECT SUM(case when td.row = 1 then 1 else 0 end) as [Bill Count],
sum(case when td.row = 1 then bh.noperson else 0 end) as [Cust Count],sum(case when td.row = 1 then td.Qty else 0 end) as Qty
,SUM(case when td.row = 1 then bh.BillDisc + bh.MemDisc + bh.Voucher + bh.ItemDisc + bh.CoupDisc + bh.NetBAmt else 0 end) as [Gross Sales]
,SUM(case when td.row = 1 then bh.BillDisc + bh.MemDisc + bh.Voucher + bh.ItemDisc + bh.CoupDisc else 0 end) as [Discount]
,sum(case when p.vattype = '1' then
case when td.row = 1 then bh.NetBAmt else 0 end 
else case when td.row = 1 then (bh.NetBAmt - bh.VatAmt1 + bh.VatAmt2) else 0 end end) as [Base Sales] --P.Yu change 20/07/2022
,sum(case when td.row = 1 then bh.VatAmt1 - bh.VatAmt2 else 0 end ) as Vat
,sum(case when p.vattype = '1' then 
case when td.row = 1 then (bh.NetBAmt + bh.VatAmt1 - bh.VatAmt2)  else 0 end
else case when td.row = 1 then bh.NetBAmt  else 0 end end) as [Net Sales],

SUM(case when td.row = 1 then  round( bh.OthChrg + bh.VatAmt2 ,2)  else 0 end) as [Service Charge],
SUM(case when td.row = 1 then   bh.OthChrg  else 0 end) AS [Base Service Charge],
SUM(case when td.row = 1 then round(bh.VatAmt2,2) else 0 end) AS [Vat Service Charge],
---
sum(case when p.vattype = '1' then
case when td.row = 1 then (bh.NetBAmt + bh.VatAmt1 + bh.OthChrg) else 0 end  
else case when td.row = 1 then (bh.NetBAmt + round(bh.OthChrg + bh.VatAmt2,2)) else 0 end end) as [Net Total],isnull((select sum(td.tendamt) where td.TendType <> 'OCR'),0) as TotalPay,
					isnull((select sum(td.tendamt) where td.TendType = 'OCR'),0) as TotalOCR,sum(td.TendAmt) as totalpay99,isnull((select sum(td.tendamt) where td.TendType + td.TendCode + td.CardName = 'CSHCSHCASH'),0) AS [CASH] ,isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0074'),0) AS [TENDER001],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0083'),0) AS [TENDER002] from #tmp_tender td (nolock)
inner join #tmp_billhdrtb bh (nolock) on td.shopcode = bh.ShopCode and td.EntDate = bh.EntDate and td.TerminalNo = bh.TerminalNo and td.BillNo = bh.BillNo
inner join posshoptb p (nolock) on p.ShopCode = bh.ShopCode
inner join PosBrnTB brn (nolock) on brn.BrandCode = p.BrandCode

 GROUP BY p.VatType ,td.TendType,td.TendCode,td.CardName,td.shopcode,td.entdate,td.terminalno,td.billno
) x





drop table #tmp_tenderx; drop table #tmp_tender; drop table #tmp_billhdrtb; drop table #tmp_billpaytbx; drop table #tmp_billpaytbz; drop table #tmp_billpaytb; 