﻿declare @shopcode0 varchar(50) = '9999';
declare @shopcode1 varchar(50) = 'XXXX';
declare @fromdate varchar(50) = '2022-09-03';
declare @todate varchar(50) = '2022-10-02'\;
declare @userid varchar(50) = '9999999';


if object_id('tempdb.dbo.#tmpStockMove') is not null
drop table #tmpStockMove
   
CREATE TABLE [dbo].[#tmpStockMove](
	[setShopCode] [nvarchar](6) NOT NULL,
	[setShopName] [nvarchar](50) NULL,
	[setItemCode] [nvarchar](20) NOT NULL,
	[setItemName] [nvarchar](40) NULL,
    [Docdate] [date] NULL,
	[StockUnit] [varchar](6) NULL,
	[UnitDes1] [varchar](30) NOT NULL,
	[OpenQty] [numeric](18, 4) NOT NULL,
	[OpenQtyAmt] [numeric](18, 4) NOT NULL,
	[OpenQtyAmtX] [numeric](38, 6) NOT NULL,
	[OpenQtyAmtZ] [numeric](38, 6) NULL,
	[GrpQty] [numeric](18, 4) NOT NULL,
	[GrpQtyAmt] [numeric](18, 4) NOT NULL,
	[GrpQtyAmtX] [numeric](18, 4) NOT NULL,
	[GrpQtyAmtZ] [numeric](18, 4) NOT NULL,
	[TrnIQty] [numeric](18, 4) NOT NULL,
	[TrnIQtyAmt] [numeric](18, 4) NOT NULL,
	[TrnIQtyAmtX] [numeric](18, 4) NOT NULL,
	[TrnIQtyAmtZ] [numeric](18, 4) NOT NULL,
	[WipI2Qty] [numeric](18, 4) NOT NULL,
	[WipI2QtyAmt] [numeric](18, 4) NOT NULL,
	[WipI2QtyAmtX] [numeric](18, 4) NOT NULL,
	[WipI2QtyAmtZ] [numeric](18, 4) NOT NULL,
	[AdjIQty] [numeric](18, 4) NOT NULL,
	[AdjIQtyAmt] [numeric](18, 4) NOT NULL,
	[AdjIQtyAmtX] [numeric](18, 4) NOT NULL,
	[AdjIQtyAmtZ] [numeric](18, 4) NOT NULL,
	[RtvQty] [numeric](18, 4) NOT NULL,
	[RtvQtyAmt] [numeric](18, 4) NOT NULL,
	[RtvQtyAmtX] [numeric](18, 4) NOT NULL,
	[RtvQtyAmtZ] [numeric](18, 4) NOT NULL,
	[TrnOQty] [numeric](18, 4) NOT NULL,
	[TrnOQtyAmt] [numeric](18, 4) NOT NULL,
	[TrnOQtyAmtX] [numeric](18, 4) NOT NULL,
	[TrnOQtyAmtZ] [numeric](18, 4) NOT NULL,
	[WipO1Qty] [numeric](18, 4) NOT NULL,
	[WipO1QtyAmt] [numeric](18, 4) NOT NULL,
	[WipO1QtyAmtX] [numeric](18, 4) NOT NULL,
	[WipO1QtyAmtZ] [numeric](18, 4) NOT NULL,
	[Wast2Qty] [numeric](18, 4) NOT NULL,
	[Wast2QtyAmt] [numeric](18, 4) NOT NULL,
	[Wast2QtyAmtX] [numeric](18, 4) NOT NULL,
	[Wast2QtyAmtZ] [numeric](18, 4) NOT NULL,
	[AdjOQty] [numeric](18, 4) NOT NULL,
	[AdjOQtyAmt] [numeric](18, 4) NOT NULL,
	[AdjOQtyAmtX] [numeric](18, 4) NOT NULL,
	[AdjOQtyAmtZ] [numeric](18, 4) NOT NULL,
	[SalesQty] [numeric](18, 4) NOT NULL,
	[SalesQtyAmt] [numeric](18, 4) NOT NULL,
	[SalesQtyAmtX] [numeric](18, 4) NOT NULL,
	[SalesQtyAmtZ] [numeric](18, 4) NOT NULL,
	[WastQty] [numeric](18, 4) NOT NULL,
	[WastQtyAmt] [numeric](18, 4) NOT NULL,
	[WastQtyAmtX] [numeric](18, 4) NOT NULL,
	[WastQtyAmtZ] [numeric](18, 4) NOT NULL,
	[TheoryUsage] [numeric](18, 4) NOT NULL,
	[TheoryUsageAmt] [numeric](18, 4) NOT NULL,
	[TheoryUsageAmtX] [numeric](18, 4) NOT NULL,
	[TheoryUsageAmtZ] [numeric](18, 4) NOT NULL,
	[TheoryStock] [numeric](18, 4) NOT NULL,
	[TheoryStockAmt] [numeric](18, 4) NOT NULL,
	[TheoryStockAmtX] [numeric](18, 4) NOT NULL,
	[TheoryStockAmtZ] [numeric](18, 4) NOT NULL,
	[CountQty] [numeric](18, 4) NOT NULL,
	[CountQtyAmt] [numeric](18, 4) NOT NULL,
	[CountQtyAmtX] [numeric](18, 4) NOT NULL,
	[CountQtyAmtZ] [numeric](18, 4) NOT NULL,
	[DiffQty] [numeric](18, 4) NOT NULL,
	[DiffQtyAmt] [numeric](18, 4) NOT NULL,
	[DiffQtyAmtX] [numeric](18, 4) NOT NULL,
	[DiffQtyAmtZ] [numeric](18, 4) NOT NULL,
	[ActualUsage] [numeric](18, 4) NOT NULL,
	[ActualUsageAmt] [numeric](18, 4) NOT NULL,
	[ActualUsageAmtX] [numeric](18, 4) NOT NULL,
	[ActualUsageAmtZ] [numeric](18, 4) NOT NULL,
	[DiffQtyPer] [numeric](18, 4) NOT NULL,
	[Turnover] [numeric](18, 4) NOT NULL,
	[AvgCostOrg] [numeric](18, 4) NOT NULL,
	[TStndCostOrg] [numeric](18, 4) NOT NULL,
	[StndCostOrg] [numeric](18, 4) NOT NULL,
	[Avgcost] [numeric](18, 4) NOT NULL,
	[TStndCost] [numeric](38, 20) NOT NULL,
	[StndCost] [numeric](38, 14) NOT NULL,
	[COGS] [int] NOT NULL,
	

) ON [PRIMARY]

delete #tmpstockmove
insert into #tmpstockmove
SELECT wh.WHCode AS setShopCode,wh.WHDes1 AS setShopName,I.ItemCode AS setItemCode,I.ItemDes1 AS setItemName, 
'' as Docdate,
I.StockUnit  AS StockUnit,isnull(F.UnitDes1,'') AS UnitDes1,
 
(isnull(bo.OpenQty,0)) as OpenQty ,
(isnull(bo.OpenQtyAmt,0)) as OpenQtyAmt ,
(isnull(bo.OpenQty,0) * isnull(isc.Stndcost, 0)) AS OpenQtyAmtX, 
(isnull(bo.openQty,0) * isnull(bc.TstndCost,0)) as OpenQtyAmtZ,
--------
sum(ISNULL(CC.IGRP,0) - ISNULL(II.OGRP,0))  AS GrpQty,
sum(ISNULL(CC.IGRPAmt,0) - ISNULL(II.OGRPAmt,0)) AS GrpQtyAmt,
sum((ISNULL(CC.IGRP,0) - ISNULL(II.OGRP,0)) * ISNULL(isc.Stndcost,0)) AS GrpQtyAmtX,
sum(ISNULL(CC.IGRPAmtZ,0) - ISNULL(II.OGRPAmtZ,0)) AS GrpQtyAmtZ,

sum(ISNULL(FF.ITRN,0)) AS TrnIQty,
sum(ISNULL(FF.ITRNAmt,0)) AS TrnIQtyAmt,
sum(ISNULL(FF.ITRN,0) * ISNULL(isc.Stndcost,0)) AS TrnIQtyAmtX,
sum(ISNULL(FF.ITRNAmtZ,0)) AS TrnIQtyAmtZ,

sum(ISNULL(AA.IWIP,0)) AS WipI2Qty,
sum(ISNULL(AA.IWIPAmt,0)) AS WipI2QtyAmt,
sum(ISNULL(AA.IWIP,0) * ISNULL(isc.Stndcost,0)) AS WipI2QtyAmtX,
sum(ISNULL(AA.IWIPAmtZ,0)) AS WipI2QtyAmtZ,

sum(ISNULL(HHIA.IADJ,0)) AS AdjIQty,
sum(ISNULL(HHIA.IADJAmt,0)) AS AdjIQtyAmt,
sum(ISNULL(HHIA.IADJ,0) * ISNULL(isc.Stndcost,0)) AS AdjIQtyAmtX,
sum(ISNULL(HHIA.IADJAmtZ,0)) AS AdjIQtyAmtZ,

sum(ISNULL(rt.ORTV,0)) AS RtvQty,
sum(ISNULL(rt.ORTVAmt,0)) AS RtvQtyAmt,
sum(ISNULL(rt.ORTV,0) * ISNULL(isc.Stndcost,0)) AS RtvQtyAmtX,
sum(ISNULL(rt.ORTVAmtZ,0)) AS RtvQtyAmtZ,

sum(ISNULL(GG.OTRN,0)) AS TrnOQty,
sum(ISNULL(GG.OTRNAmt,0)) AS TrnOQtyAmt,
sum(ISNULL(GG.OTRN,0) * ISNULL(isc.Stndcost,0)) AS TrnOQtyAmtX,
sum(ISNULL(GG.OTRNAmtZ,0)) AS TrnOQtyAmtZ,

sum(ISNULL(EE.OWIP,0)) AS WipO1Qty,
sum(ISNULL(EE.OWIPAmt,0)) AS WipO1QtyAmt,
sum(ISNULL(EE.OWIP,0) * ISNULL(isc.Stndcost,0)) AS WipO1QtyAmtX,
sum(ISNULL(EE.OWIPAmtZ,0)) AS WipO1QtyAmtZ,

sum(ISNULL(DD.OWS2,0)) AS Wast2Qty,
sum(ISNULL(DD.OWS2Amt,0)) AS Wast2QtyAmt,
sum(ISNULL(DD.OWS2,0) * ISNULL(isc.Stndcost,0)) AS Wast2QtyAmtX,
sum(ISNULL(DD.OWS2AmtZ,0)) AS Wast2QtyAmtZ,  

sum(ISNULL(HHOA.OADJ,0)) AS AdjOQty,
sum(ISNULL(HHOA.OADJAmt,0)) AS AdjOQtyAmt,
sum(ISNULL(HHOA.OADJ,0) * ISNULL(isc.Stndcost,0)) AS AdjOQtyAmtX,
sum(ISNULL(HHOA.OADJAmtZ,0)) AS AdjOQtyAmtZ,

sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) AS SalesQty,
sum(ISNULL(HH.SaleAmt,0) - ISNULL(HHV.IVSLAmt,0)) AS SalesQtyAmt,
sum((ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) * ISNULL(isc.Stndcost,0)) AS SalesQtyAmtX,
sum((ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0))  
* case isnull(bc.TStndCost,0) when 0 then isnull(isc.StndCost,0) else isnull(bc.TStndCost,0) end ) AS SalesQtyAmtZ,

sum(ISNULL(BB.OWST,0)) AS WastQty,
sum(ISNULL(BB.OWSTAmt,0)) AS WastQtyAmt,
sum(ISNULL(BB.OWST,0) * ISNULL(isc.Stndcost,0)) AS WastQtyAmtX,
sum(ISNULL(BB.OWSTAmtZ,0)) AS WastQtyAmtZ,
-----
(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) +  sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0))) AS [TheoryUsage],
sum(ISNULL(HH.SaleAmt,0) - ISNULL(HHV.IVSLAmt,0)) +  sum(ISNULL(BB.OWSTAmt,0)) +sum(ISNULL(DD.OWS2Amt,0))  AS [TheoryUsageAmt],
sum((ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0) +ISNULL(BB.OWST,0)+ ISNULL(DD.OWS2,0)) * ISNULL(isc.Stndcost,0))  AS [TheoryUsageAmtX],
sum((ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0) +ISNULL(BB.OWST,0)+ ISNULL(DD.OWS2,0)))* ISNULL(bc.TStndCost,0)  AS [TheoryUsageAmtZ],

((ISNULL(bc.EndBalqty,0)) - sum( ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)))  AS [TheoryStock],
(ISNULL(bc.EndBalqty,0) - sum( ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) * isnull(bc.Avgcost,0) AS [TheoryStockAmt],
(ISNULL(bc.EndBalqty,0) - sum( ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) * isnull(isc.Stndcost,0) AS [TheoryStockAmtX],
(ISNULL(bc.EndBalqty,0) - sum( ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) * ISNULL(bc.TStndCost,0) AS [TheoryStockAmtZ], 
--
(ISNULL(bc.EndBalqty,0)) as CountQty,
(ISNULL(bc.EndBalamt,0))  as CountQtyAmt,
(ISNULL(bc.EndBalqty,0) * isnull(isc.Stndcost,0)) as CountQtyAmtX,
(ISNULL(bc.EndBalqty,0) * ISNULL(bc.TStndCost,0)) as CountQtyAmtZ,

--
sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)) AS DiffQty,
sum(ISNULL(vv.ICNTAmt,0) - ISNULL(vv2.OCNTAmt,0)) AS DiffQtyAmt,
sum((ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)) * ISNULL(isc.Stndcost,0)) AS DiffQtyAmtX,
sum(ISNULL(vv.ICNTAmtZ,0) - ISNULL(vv2.OCNTAmtZ,0)) AS DiffQtyAmtZ,

(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)))  AS [ActualUsage],
(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) * isnull(bc.Avgcost,0) AS [ActualUsageAmt],
(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) * isnull(isc.StndCost,0) AS [ActualUsageAmtX],
(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0))) 
* case isnull(bc.TStndCost,0) when 0 then isnull(isc.StndCost,0) else isnull(bc.TStndCost,0) end AS [ActualUsageAmtZ],

((sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)))/ 
(case when sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) +  sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) = 0 then 1 else sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) +  sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) end) - 1)*100 AS DiffQtyPer,

(sum(ISNULL(HH.Sale,0) - ISNULL(HHV.IVSL,0)) + sum(ISNULL(BB.OWST,0)) + sum(ISNULL(DD.OWS2,0)) - sum(ISNULL(vv.ICNT,0) - ISNULL(vv2.OCNT,0)))/ case when (isnull(bo.OpenQty,0)) + sum(ISNULL(FF.ITRN,0)) = 0 then 1 else ((isnull(bo.OpenQty,0)) + sum(ISNULL(FF.ITRN,0))) end AS Turnover,

cast(isnull(bc.Avgcost,0) as numeric(17,4)) as AvgCostOrg ,
cast(case isnull(bc.TStndCost,0) when 0 then isnull(isc.StndCost,0) else isnull(bc.TStndCost,0) end as numeric(17,4)) as TStndCostOrg, 
cast(isnull(isc.StndCost,0) as numeric(17,4)) as StndCostOrg, 

cast(isnull(bc.Avgcost,0) as numeric(17,4)) * (ISNULL(bc.EndBalqty,0)) as Avgcost ,
cast(case isnull(bc.TStndCost,0) when 0 then isnull(isc.StndCost,0) else isnull(bc.TStndCost,0) end as numeric(17,4)) * (ISNULL(bc.EndBalqty,0)) as TStndCost, 
cast(isnull(isc.StndCost,0) as numeric(17,4)) * (ISNULL(bc.EndBalqty,0)) as StndCost, 
0 as COGS

FROM Ibalance g (NOLOCK) 
Inner join ItemMast i (nolock) on i.itemcode = g.itemcode
inner join WareHouseTB wh (nolock) on g.ShopCode = wh.WHCode

inner join (select p.shopcode
from posshoptb p (nolock)
inner join extstructuretb ext (nolock) 
on (p.shgrpcode = ext.groupcode or p.shtypcode = ext.typecode or p.shgrpcode = ext.groupcode 
or p.shclscode = ext.classcode or p.shopcode = ext.shopcode)
where ext.recordtype = 'USER' and ext.usrcode = '9999999'
group by p.shopcode 
) us on us.shopcode = g.ShopCode

-----Add New--Open Qty---------
Left outer join (SELECT inv.branch,inv.itemcode,
isnull(inv.xbalqty,0) as OpenQty, 
isnull(inv.xbalAmt,0) as  OpenQtyAmt
FROM InvCard inv (NOLOCK) 
inner join (
select branch,itemcode, max(Itrandate) as xdocdate ,max(tranrun) as xtranrun
from invcard a (nolock)  
where Itrandate <  convert(varchar,@fromdate,23) + ' 00:00:00'
group by branch,itemcode
) b on inv.branch = b.branch and inv.itemcode = b.itemcode

where  inv.Itrandate = b.xdocdate and inv.tranrun = b.xtranrun  ) bo
on g.shopcode = bo.branch and g.itemcode = bo.itemcode
-----------Balance Qty--------------
left Outer join (SELECT  inv.branch,inv.itemcode,
	isnull(inv.xbalqty,0) as EndBalQTY, 
	isnull(inv.xBalamt,0) as EndBalAmt,
	isnull(inv.xAvgCost,0)  as Avgcost,
	(isnull(inv.balamt,0) / case isnull(inv.itrnqty,0) when 0 then 1 else inv.itrnqty end) as TStndCost

    FROM InvCard inv (NOLOCK) 
	inner join (
select branch,itemcode, max(a.itrandate) as xdocdate ,  max(tranrun) as xTranrun 
from invcard a (nolock) 
where a.Itrandate <= convert(varchar,@todate,23) + ' 23:59:59'
group by branch,itemcode) b 
on inv.branch = b.branch and inv.itemcode = b.itemcode
	     
where  inv.Itrandate = b.xdocdate  and inv.tranrun = b.xtranrun ) bc
on wh.whcode = bc.branch and g.itemcode = bc.itemcode
------Get Standard Cost------
left outer join (select ga.SWHCode,ga.itemcode,
	( (ISNULL(gb.ItemCost, 0) / ISNULL(gr.ConvFact, 1))) AS StndCost 
 from 
(SELECT   cs.SWHCode,cs.[Source],  cs.ItemCode, max(cs.unitCode) as unitcode
FROM ISupCost cs (NOLOCK)
WHERE cs.[Source] = 'W'    
group by cs.SWHCode,cs.[Source] ,  cs.ItemCode  ) ga
inner join isupcost gb(nolock) on ga.swhcode = gb.swhcode  and ga.[Source] = gb.[Source]
and ga.itemcode = gb.itemcode and ga.unitcode = gb.unitcode
LEFT OUTER JOIN (select Itemcode,UnitCode, (ConvFact) as convfact   
from IGrpUnitTB gr (NOLOCK) ) gr	  
ON ga.ItemCode = gr.ItemCode AND ga.UnitCode = gr.UnitCode ) isc
ON isc.SWHCode = g.shopcode AND isc.ItemCode = g.ItemCode  	
---------------
LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.itrnQty),0) AS IWIP,
ISNULL(SUM(A.itrnAmt),0) AS IWIPAmt,ISNULL(SUM(A.balamt),0) AS IWIPAmtZ
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'IWIP'  
GROUP BY  A.Branch,A.ItemCode) AA ON g.ItemCode = AA.ItemCode and g.ShopCode = aa.Branch 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,SUM(A.ItrnQty) AS OWST ,
ISNULL(SUM(A.itrnAmt),0) AS OWSTAmt,ISNULL(SUM(A.balamt),0) AS OWSTAmtZ
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OWST' 
GROUP BY  A.Branch,A.ItemCode) BB ON g.ItemCode = BB.ItemCode and g.ShopCode = bb.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,SUM(A.ItrnQty) AS IGRP,
ISNULL(SUM(A.itrnAmt),0) AS IGRPAmt,ISNULL(SUM(A.balamt),0) AS IGRPAmtZ
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'IGRP' 
GROUP BY  A.Branch,A.ItemCode) CC ON g.ItemCode = CC.ItemCode and g.ShopCode = cc.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,SUM(A.ItrnQty) AS OGRP,
ISNULL(SUM(A.itrnAmt),0) AS OGRPAmt,ISNULL(SUM(A.balamt),0) AS OGRPAmtZ 
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OGRP' 
GROUP BY  A.Branch,A.ItemCode) II ON g.ItemCode = II.ItemCode and g.ShopCode = ii.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,SUM(A.ItrnQty) AS OWS2 ,
ISNULL(SUM(A.itrnAmt),0) AS OWS2Amt,ISNULL(SUM(A.balamt),0) AS OWS2AmtZ 
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OWS2' 
GROUP BY  A.Branch,A.ItemCode) DD ON g.ItemCode = DD.ItemCode and g.ShopCode = dd.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,SUM(A.ItrnQty) AS OWIP ,
ISNULL(SUM(A.itrnAmt),0) AS OWIPAmt,ISNULL(SUM(A.balamt),0) AS OWIPAmtZ  
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OWIP' 
GROUP BY  A.Branch,A.ItemCode) EE ON g.ItemCode = EE.ItemCode and g.ShopCode = ee.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.iTrnQty),0) AS ITRN ,
ISNULL(SUM(A.itrnAmt),0) AS ITRNAmt,ISNULL(SUM(A.balamt),0) AS ITRNAmtZ   
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'ITRN' 
GROUP BY  A.Branch,A.ItemCode) FF ON g.ItemCode = FF.ItemCode and g.ShopCode = ff.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS OTRN ,
ISNULL(SUM(A.itrnAmt),0) AS OTRNAmt,ISNULL(SUM(A.balamt),0) AS OTRNAmtZ    
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OTRN'  
GROUP BY  A.Branch,A.ItemCode) GG ON g.ItemCode = GG.ItemCode and g.ShopCode = gg.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS Sale,
ISNULL(SUM(A.itrnAmt),0) AS SALeAmt,ISNULL(SUM(A.balamt),0) AS SALeAmtZ     
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OSAL'
GROUP BY  A.Branch,A.ItemCode) HH ON g.ItemCode = HH.ItemCode and g.ShopCode = hh.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS IVSL ,
ISNULL(SUM(A.itrnAmt),0) AS IVSLAmt,ISNULL(SUM(A.balamt),0) AS IVSLAmtZ    
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'IVSL'  
GROUP BY  A.Branch,A.ItemCode) HHV ON g.ItemCode = HHV.ItemCode and g.ShopCode = hhv.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS IADJ ,
ISNULL(SUM(A.itrnAmt),0) AS IADJAmt,ISNULL(SUM(A.balamt),0) AS IADJAmtZ     
FROM Invcard A (nolock) 
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'IADJ'  
GROUP BY  A.Branch,A.ItemCode) HHIA ON g.ItemCode = HHIA.ItemCode and g.ShopCode = hhia.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS OADJ ,
ISNULL(SUM(A.itrnAmt),0) AS OADJAmt,ISNULL(SUM(A.balamt),0) AS OADJAmtZ    
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OADJ'  
GROUP BY  A.Branch,A.ItemCode) HHOA ON g.ItemCode = HHOA.ItemCode and g.ShopCode = hhoa.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS ICNT,
ISNULL(SUM(A.itrnAmt),0) AS ICNTAmt,ISNULL(SUM(A.balamt),0) AS ICNTAmtZ ,
ISNULL(SUM(A.xBalqty),0) AS TCNTQtyI,ISNULL(SUM(A.xbalamt),0) AS TCNTAmtI,
ISNULL(SUM((A.balamt / case isnull(a.ITRNQty,0) when 0 then 1 else a.Itrnqty end) * isnull(a.xBalqty,0)),0) AS TCNTAmtZI
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'ICNT' 
GROUP BY  A.Branch,A.ItemCode) vv ON g.ItemCode = vv.ItemCode and g.ShopCode = vv.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS OCNT, 
ISNULL(SUM(A.itrnAmt),0) AS OCNTAmt ,ISNULL(SUM(A.balamt),0) AS OCNTAmtZ,
ISNULL(SUM(A.xBalqty),0) AS TCNTQtyO,ISNULL(SUM(A.xbalamt),0) AS TCNTAmtO,
ISNULL(SUM((A.balamt / case isnull(a.ITRNQty,0) when 0 then 1 else a.Itrnqty end) * isnull(a.xBalqty,0)),0) AS TCNTAmtZO     
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'OCNT' 
GROUP BY  A.Branch,A.ItemCode) vv2 ON g.ItemCode = vv2.ItemCode and g.ShopCode = vv2.Branch 
 

LEFT OUTER JOIN (SELECT  A.Branch,A.ItemCode,ISNULL(SUM(A.ITrnQty),0) AS ORTV, 
ISNULL(SUM(A.itrnAmt),0) AS ORTVAmt,ISNULL(SUM(A.balamt),0) AS ORTVAmtZ     
FROM Invcard A (nolock)
WHERE A.branch between @shopcode0 and @shopcode1 AND CAST(A.ITranDate AS DATE) between @Fromdate and @todate  and A.ItrnCode = 'ORTV' 
GROUP BY  A.Branch,A.ItemCode) rt ON g.ItemCode = rt.ItemCode and g.ShopCode = rt.Branch  

LEFT OUTER JOIN IUnitTB F(nolock)  ON  I.StockUnit  = F.UnitCode
----  
WHERE g.shopcode between @shopcode0 and @shopcode1  AND i.ItemFlag = '0'   AND wh.WHStat = '0'  
 
--------------------------------------
GROUP BY wh.WHCode, wh.WHDes1,I.ItemCode, I.ItemDes1,bo.OpenQty, bo.OpenQtyAmt,
I.StockUnit , F.UnitDes1, 
bc.AvgCost, bc.tStndCost, isc.Stndcost,
bc.EndBalqty, bc.EndBalAmt
 

SELECT  
xa.setShopCode,xa.setShopName,xa.setItemCode,xa.setItemName,xa.docdate,
xa.StockUnit, xa.UnitDes1 , 

sum(isnull(xa.OpenQty, 0)) as OpenQty ,
sum(isnull(xa.OpenQtyAmt, 0)) as OpenQtyAmt ,
sum(isnull(xa.OpenQtyAmtX, 0))  AS OpenQtyAmtX,
sum(isnull(xa.OpenQtyAmtZ, 0) )  as OpenQtyAmtZ,

----
sum(xa.GrpQty) AS GrpQty,
sum(xa.GrpQtyAmt) AS GrpQtyAmt,
sum(xa.GrpQtyAmtX) AS GrpQtyAmtX,
sum(xa.GrpQtyAmtZ) AS GrpQtyAmtZ,
sum(xa.TrnIQty) AS TrnIQty,
sum(xa.TrnIQtyAmt) AS TrnIQtyAmt,
sum(xa.TrnIQtyAmtX) AS TrnIQtyAmtX,
sum(xa.TrnIQtyAmtZ) AS TrnIQtyAmtZ,
sum(xa.WipI2Qty) AS WipI2Qty,
sum(xa.WipI2QtyAmt) AS WipI2QtyAmt,
sum(xa.WipI2QtyAmtX) AS WipI2QtyAmtX,
sum(xa.WipI2QtyAmtZ) AS WipI2QtyAmtZ,
sum(xa.AdjIQty) AS AdjIQty,
sum(xa.AdjIQtyAmt) AS AdjIQtyAmt,
sum(xa.AdjIQtyAmtX) AS AdjIQtyAmtX,
sum(xa.AdjIQtyAmtZ) AS AdjIQtyAmtZ,
sum(xa.RtvQty) AS RtvQty,
sum(xa.RtvQtyAmt) AS RtvQtyAmt,
sum(xa.RtvQtyAmtX) AS RtvQtyAmtX,
sum(xa.RtvQtyAmtZ) AS RtvQtyAmtZ,
sum(xa.TrnOQty) AS TrnOQty,
sum(xa.TrnOQtyAmt) AS TrnOQtyAmt,
sum(xa.TrnOQtyAmtX) AS TrnOQtyAmtX,
sum(xa.TrnOQtyAmtZ) AS TrnOQtyAmtZ,
sum(xa.WipO1Qty) AS WipO1Qty,
sum(xa.WipO1QtyAmt) AS WipO1QtyAmt,
sum(xa.WipO1QtyAmtX) AS WipO1QtyAmtX,
sum(xa.WipO1QtyAmtZ) AS WipO1QtyAmtZ,
sum(xa.Wast2Qty) AS Wast2Qty,
sum(xa.Wast2QtyAmt) AS Wast2QtyAmt,
sum(xa.Wast2QtyAmtX) AS Wast2QtyAmtX,
sum(xa.Wast2QtyAmtZ) AS Wast2QtyAmtZ,
sum(xa.AdjOQty) AS AdjOQty,
sum(xa.AdjOQtyAmt) AS AdjOQtyAmt,
sum(xa.AdjOQtyAmtX) AS AdjOQtyAmtX,
sum(xa.AdjOQtyAmtZ) AS AdjOQtyAmtZ,

sum(xa.SalesQty) AS SalesQty,
sum(xa.SalesQtyAmt) AS SalesQtyAmt,
sum(xa.SalesQtyAmtX) AS SalesQtyAmtX,
sum(xa.SalesQtyAmtZ) AS SalesQtyAmtZ,

sum(xa.WastQty) AS WastQty,
sum(xa.WastQtyAmt) AS WastQtyAmt,
sum(xa.WastQtyAmtX) AS WastQtyAmtX,
sum(xa.WastQtyAmtZ) AS WastQtyAmtZ,

-----

sum(xa.[TheoryUsage]) as [TheoryUsage] ,
sum(xa.TheoryUsageAmt) as [TheoryUsageAmt] ,
sum(xa.TheoryUsageAmtX) as [TheoryUsageAmtX] ,
sum(xa.TheoryUsageAmtZ) as [TheoryUsageAmtZ] ,

sum(xa.[TheoryStock])  AS[TheoryStock],
sum(xa.[TheoryStockAmt])  AS[TheoryStockAmt],
sum(xa.[TheoryStockAmtX])  AS[TheoryStockAmtX],
sum(xa.[TheoryStockAmtZ])  AS[TheoryStockAmtZ],

sum(ISNULL(xa.CountQty, 0)) as CountQty,
sum(ISNULL(xa.CountQtyAmt, 0)) as CountQtyAmt,
sum(ISNULL(xa.CountQtyAmtX, 0)) as CountQtyAmtX,
sum(ISNULL(xa.CountQtyAmtZ, 0)) as CountQtyAmtZ,

----
sum(xa.DiffQty) AS DiffQty,
sum(xa.DiffQtyAmt) AS DiffQtyAmt,
sum(xa.DiffQtyAmtX) AS DiffQtyAmtX,
sum(xa.DiffQtyAmtZ) AS DiffQtyAmtZ,
SUM(XA.ActualUsage) AS[ActualUsage],
sum(xa.ActualUsageAmt) AS[ActualUsageAmt],
sum(xa.ActualUsageAmtX) AS[ActualUsageAmtX],
sum(xa.ActualUsageAmtZ) AS[ActualUsageAmtZ],
SUM(xa.DiffQtyPer) AS DiffQtyPer,
sum(xa.Turnover) AS Turnover,

cast(xa.AvgCostOrg as Numeric(15, 4))   as AvgCostOrg ,
cast(xa.StndCostOrg as Numeric(15, 4)) as StndCostOrg, 
cast(xa.TStndCostOrg as Numeric(15, 4)) as TStndCostOrg, 

cast(xa.Avgcost as Numeric(15, 4))   as Avgcost ,
cast(xa.StndCost as Numeric(15, 4)) as StndCost, 
cast(xa.TStndCost as Numeric(15, 4)) as TStndCost, 
SUM(XA.ActualUsage) * xa.AvgCostOrg  as COGS,
SUM(XA.ActualUsage) * xa.StndCostOrg  as COGSX,
SUM(XA.ActualUsage) * xa.TStndCostOrg  as COGSZ

from #tmpstockmove xa (nolock)
GROUP BY xa.setShopCode,xa.setShopName,xa.setItemCode,xa.setItemName,xa.docdate , xa.StockUnit, xa.UnitDes1,
xa.Avgcost, xa.TStndCost, xa.StndCost, xa.AvgCostOrg, xa.TStndCostOrg, xa.StndCostOrg 

order by xa.setshopcode,xa.SetItemCode,xa.docdate
drop table #tmpStockMove;
    
