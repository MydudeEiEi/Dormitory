declare @shopcode0 varchar(50) = '9999';
declare @shopcode1 varchar(50) = 'XXXX';
declare @fromterminal varchar(50) = '01';
declare @toterminal varchar(50) = '99';
declare @fromdate varchar(50) = '2022-11-20';
declare @todate varchar(50) = '2022-11-21';
declare @fromtime varchar(50) = '00:00';
declare @totime varchar(50) = '23:59';
declare @PrcType varchar(50) = 'GROUPPRICE';
declare @userid varchar(50) = '9999999';


                            select con.setShopCode,con.setShopName,con.[Terminal No] AS [Terminal No],con.EntDate,con.[Date Period],con.Mode,con.setItemCode,con.setItemName,[Org. Price] = case SUM(con.Qty) when 0 then 0 else case @prctype when 'AVERAGEPRICE' then round( SUM(con.[Gross Sales]) / sum(con.Qty +.00000000001),2) else (sum(con.[Org. Price]) / count(con.[Org. Price])) end end,0 AS Seq,SUM(con.Qty) AS Qty,SUM(con.[In Set Qty]) as [In Set Qty],0.0000 as [Qty(%)],SUM(con.[Gross Sales]) AS [Gross Sales],SUM(con.[Discount]) AS [Discount],SUM(con.[Base Sales]) AS [Base Sales],SUM(con.[Service Charge]) AS [Service Charge],SUM(con.Vat) AS Vat,SUM(con.[Net Sales]) AS [Net Sales],SUM(con.[Total Sales]) AS [Total Sales],0.0000 as [Total Sales(%)],0.0000 AS [Item Cost],0.0000 AS [Standard Cost],0.0000 AS [Transaction Std Cost],0.0000 AS [Transaction Avg Cost],0.0000 AS [Standard Cost(%)],0.0000 AS [Transaction Cost(%)],0.0000 AS Margin,0.0000 AS [Margin(%)],SUM(con.[Ticket Count]) AS [Ticket Count]
                            from
                            (
                            select sale.setShopCode,sale.setShopName,sale.TerminalNo AS [Terminal No],sale.EntDate,sale.[Date Period],sale.Mode,sale.setItemCode,sale.setItemName,sale.[Org. Price],0 AS Seq,SUM(sale.Qty) AS Qty,SUM(sale.[In Set Qty]) as [In Set Qty],0.0000 as [Qty(%)],SUM(sale.[Gross Sales]) AS [Gross Sales],SUM(sale.[Discount]) AS [Discount],SUM(sale.[Base Sales]) AS [Base Sales],SUM(sale.[Service Charge]) AS [Service Charge],SUM(sale.Vat) AS Vat,SUM(sale.[Net Sales]) AS [Net Sales],SUM(sale.[Total Sales]) AS [Total Sales],0.0000 as [Total Sales(%)],0.0000 AS [Item Cost],0.0000 AS [Standard Cost],0.0000 AS [Transaction Std Cost],0.0000 AS [Transaction Avg Cost],0.0000 AS [Standard Cost(%)],0.0000 AS [Transaction Cost(%)],0.0000 AS Margin,0.0000 AS [Margin(%)],SUM(sale.[Ticket Count]) AS [Ticket Count]
                            from
                            (
                            select brn.brandnam1 as Brand ,  i.ItemCode,bh.PriceMode, b.ShopCode AS setShopCode,p.ShopDes1 AS setShopName,b.TerminalNo,b.EntDate,convert(varchar,b.EntDate,103) AS [Date Period],pm.ModeDes1 AS Mode,b.SubCode AS setItemCode,i.itemdes1 AS setItemName,case when b.SellPrice < 0 then -b.SellPrice else b.sellprice end AS [Org. Price],
                            SUM(case b.itemcode when b.subcode then b.ActQty else 0 end) AS [Qty],
                            SUM(case b.itemstat when '1' then (case b.itemcode when b.subcode then 0 else b.ActQty end) else 0 end) AS [In Set Qty],
                            SUM(b.ItemDis + b.totalDis + b.Coupon + b.Voucher + b.NetAmt)  AS [Gross Sales],
                            SUM(b.ItemDis + b.totalDis + b.Coupon + b.Voucher)  AS [Discount],
                            (CASE p.VatType
                            WHEN '1' THEN SUM(b.NetAmt) 
                            ELSE SUM(b.NetAmt - b.VatAmt) 
                            END) AS [Base Sales],
                            (CASE WHEN ISNULL(v.VatP, 0) > 0 THEN SUM(b.VatAmt + ((b.AddAmt/(ISNULL(v.VatP, 0) + 100)) * ISNULL(v.VatP, 0))) 
                            ELSE SUM(b.VatAmt + ((b.AddAmt * ISNULL(v.VatP, 0))/100))  
                            END) AS Vat,
                            (CASE p.VatType WHEN '1' THEN SUM(b.NetAmt + b.VatAmt)  ELSE SUM(b.NetAmt)  END) AS [Net Sales],
                            (CASE p.VatType WHEN '1' THEN SUM(b.NetAmt + b.VatAmt + b.AddAmt)  ELSE SUM(b.NetAmt + b.AddAmt)  END) AS [Total Sales],
                            --OLD
                            --(CASE WHEN ISNULL(v.VatP, 0) > 0 THEN SUM((b.AddAmt/(ISNULL(v.VatP, 0) + 100)) * 100) 
                            --ELSE SUM(b.AddAmt) 
                            --END) AS [Service Charge],
                            --New
                            SUM(b.AddAmt) AS [Service Charge],
                            COUNT((bh.ShopCode + bh.BillNo)) AS [Ticket Count]
                            
                            
                            
                            --from billhdrtb bh (nolock)
                            from posshoptb p (nolock)
                             inner join posbrntb brn (nolock) on brn.brandcode = p.brandcode 
                            inner join billHdrtb bh (nolock) on p.ShopCode = bh.ShopCode
                            inner join billdtltb b (nolock) on bh.ShopCode = b.ShopCode and bh.TerminalNo = b.TerminalNo and bh.BillDate = b.BillDate and bh.BillNo = b.BillNo And bh.BillType = b.BillType
                            inner join itmmastb i (nolock) on i.ItemCode = b.subcode 
                            --inner join ShpItmTB i2 (nolock) on i2.shopcode = b.shopcode and  i2.ItemCode = i.ItemCode
                            --08/04/2021:P.Yu Update
                            INNER JOIN ItmCatTB c (NOLOCK) ON i.CatCode0 = c.CatCode
                            INNER JOIN VatCodTB v (NOLOCK) ON v.VatCode = i.VatCode
                            INNER JOIN PrcModTB pm (NOLOCK) ON bh.PriceMode = pm.PriceMode
                            --inner join posshoptb p (nolock) on p.ShopCode = bh.ShopCode
                            
                            inner join
                            (
                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shgrpcode = ext.groupcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shclscode = ext.classcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shtypcode = ext.typecode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shopcode = ext.shopcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'
                            ) us on us.shopcode = p.shopcode

                            
                            
                            
                            
                            WHERE (b.ShopCode BETWEEN @shopcode0 AND @shopcode1) AND (b.TerminalNo BETWEEN @fromterminal AND @toterminal) AND (b.EntDate BETWEEN @fromdate AND @todate) AND (LEFT(bh.BillTime,5) BETWEEN @fromtime AND @totime) AND bh.billstatus not in ('4X','5X')  
                            group by i.ItemCode,bh.PriceMode,p.VatType,v.VatP , brn.brandnam1,b.ShopCode,p.ShopDes1,b.TerminalNo,b.EntDate,pm.ModeDes1,b.SubCode,i.itemdes1,b.sellprice  
                            ) sale

                            
                             GROUP BY sale.setShopCode,sale.setShopName,sale.TerminalNo,sale.EntDate,sale.[Date Period],sale.Mode,sale.setItemCode,sale.setItemName,sale.[Org. Price]  

                            UNION

                            select con.setShopCode,con.setShopName,con.TerminalNo AS [Terminal No],con.BillDate,con.[Date Period],con.Mode,con.setItemCode,con.setItemName,con.[Org. Price],0 AS Seq,SUM(con.Qty) AS Qty,SUM(con.[In Set Qty]) as [In Set Qty],0.0000 as [Qty(%)],SUM(con.[Gross Sales]) AS [Gross Sales],SUM(con.[Discount]) AS [Discount],SUM(con.[Base Sales]) AS [Base Sales],SUM(con.[Service Charge]) AS [Service Charge],SUM(con.Vat) AS Vat,SUM(con.[Net Sales]) AS [Net Sales],SUM(con.[Total Sales]) AS [Total Sales],0.0000 as [Total Sales(%)],0.0000 AS [Item Cost],0.0000 AS [Standard Cost],0.0000 AS [Transaction Std Cost],0.0000 AS [Transaction Avg Cost],0.0000 AS [Standard Cost(%)],0.0000 AS [Transaction Cost(%)],0.0000 AS Margin,0.0000 AS [Margin(%)],SUM(con.[Ticket Count]) AS [Ticket Count]
                            from
                            (
                            select brn.brandnam1 as Brand ,  i.ItemCode,bh.PriceMode, b.ShopCode AS setShopCode,p.ShopDes1 AS setShopName,b.TerminalNo,b.BillDate,convert(varchar,b.BillDate,103) AS [Date Period],pm.ModeDes1 AS Mode,b.SubCode AS setItemCode,i.itemdes1 AS setItemName,case when (b.ordqty ) < 0 then -(b.ordqty / (case when b.actqty = 0 then 1 else b.actqty end)) else (b.ordqty / (case when b.actqty = 0 then 1 else b.actqty end)) end  AS [Org. Price],
                            0 AS [Qty],
                            SUM(b.ActQty) AS [In Set Qty],
                            0 AS [Gross Sales],
                            0 AS [Discount],
                            0 AS [Base Sales],
                            0 AS Vat,
                            0 AS [Net Sales],
                            0 AS [Total Sales],
                            0 AS [Service Charge],
                            0 AS [Ticket Count]
                            
                            
                            
                            --from billhdrtb bh (nolock)
                            from posshoptb p (nolock)
                             inner join posbrntb brn (nolock) on brn.brandcode = p.brandcode 
                            inner join billHdrtb bh (nolock) on p.ShopCode = bh.ShopCode
                            inner join billdtl2tb b (nolock) on bh.ShopCode = b.ShopCode and bh.TerminalNo = b.TerminalNo and bh.BillDate = b.BillDate and bh.BillNo = b.BillNo And bh.BillType = b.BillType
                            inner join itmmastb i (nolock) on i.ItemCode = b.subcode 
                            --inner join ShpItmTB i2 (nolock) on i2.shopcode = b.shopcode and  i2.ItemCode = i.ItemCode
                            --08/04/2021:P.Yu Update
                            INNER JOIN ItmCatTB c (NOLOCK) ON i.CatCode0 = c.CatCode
                            INNER JOIN VatCodTB v (NOLOCK) ON v.VatCode = i.VatCode
                            INNER JOIN PrcModTB pm (NOLOCK) ON bh.PriceMode = pm.PriceMode
                            --inner join posshoptb p (nolock) on p.ShopCode = bh.ShopCode
                            
                            inner join
                            (
                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shgrpcode = ext.groupcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shclscode = ext.classcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shtypcode = ext.typecode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shopcode = ext.shopcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'
                            ) us on us.shopcode = p.shopcode

                            
                            
                            
                            WHERE (b.ShopCode BETWEEN @shopcode0 AND @shopcode1) AND (b.TerminalNo BETWEEN @fromterminal AND @toterminal) AND (b.BillDate BETWEEN @fromdate AND @todate) AND (LEFT(bh.BillTime,5) BETWEEN @fromtime AND @totime) AND bh.billstatus not in ('4X','5X')  
                            group by i.ItemCode,bh.PriceMode,p.VatType,v.VatP , brn.brandnam1,b.ShopCode,p.ShopDes1,b.TerminalNo,b.BillDate,pm.ModeDes1,b.SubCode,i.itemdes1,b.ordqty,b.actqty  
                            ) con
                             
                             GROUP BY con.setShopCode,con.setShopName,con.TerminalNo,con.BillDate,con.[Date Period],con.Mode,con.setItemCode,con.setItemName,[Org. Price] 

                            ) con
                             
                             GROUP BY con.setShopCode,con.setShopName,con.[Terminal No],con.EntDate,con.[Date Period],con.Mode,con.setItemCode,con.setItemName,[Org. Price] 
                             ORDER BY setShopCode,[Terminal No],EntDate,Mode,setItemCode ; 
