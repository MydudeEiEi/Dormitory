select MemCode, MemType, 'e-Membership' as MemTName1,
FirstName1, LastName1, FirstName2, Gender, Birthdate, email,
Telephone1, Address1, 
convert(nvarchar(20),StartDate,103) as [Start Date], convert(nvarchar(20),ExpireDate,103) as [Expire Date],
case when MemStatus = '3' then 'Active' else 'Inactive' end as MemStatus
from MemberTB(nolock)
where memcode = TempCode and MemType = 'PC02' 
and StartDate between '2018-01-01' and '2022-05-31'
order by StartDate, MemCode