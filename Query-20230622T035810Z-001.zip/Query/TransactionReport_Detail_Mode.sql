declare @shopcode0 varchar(50) = '9999';
declare @shopcode1 varchar(50) = 'XXXX';
declare @fromterminal varchar(50) = '01';
declare @toterminal varchar(50) = '99';
declare @fromdate varchar(50) = '2022-07-01';
declare @todate varchar(50) = '2022-07-31';
declare @fromtime varchar(50) = '00:00';
declare @totime varchar(50) = '23:59';
declare @userid varchar(50) = '9999999';
declare @catecode0 varchar(50) = '';


                select bh.* into #tmp_billhdrtb
                from billhdrtb bh (nolock)
                
                inner join posshoptb p (nolock) on p.shopcode = bh.shopcode
                
                            inner join
                            (
                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shgrpcode = ext.groupcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shclscode = ext.classcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shtypcode = ext.typecode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'

                            union

                            select p.shopcode
                            from posshoptb p (nolock)
                            inner join extstructuretb ext (nolock) on p.shopcode = ext.shopcode
                            where ext.recordtype = 'user' and ext.usrcode = '9999999'
                            ) us on us.shopcode = p.shopcode

                            
                WHERE (bh.ShopCode BETWEEN @shopcode0 AND @shopcode1) AND (bh.TerminalNo BETWEEN @fromterminal AND @toterminal) AND (bh.EntDate BETWEEN @fromdate AND @todate) AND (LEFT(bh.BillTime,5) BETWEEN @fromtime AND @totime) 

                select bp.shopcode,bp.entdate,bp.TerminalNo,bp.billno,bp.tendtype,bp.tendcode,bp.cardname,bp.tendamt into #tmp_billpaytbx
                from #tmp_billhdrtb bh (nolock)
                inner join billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
                where bp.[sequence] >= 5000 AND bp.[sequence] < 8000 and bp.TendCode <> 'CHG' and ((bp.TendCode <> 'DRAR' and bp.TendAmt <> 0) or bp.TendCode = 'DRAR' and bp.TendAmt <> 0)

                select bp.shopcode,bp.entdate,bp.TerminalNo,bp.billno,bp.tendtype,bp.tendcode,bp.cardname,bp.tendamt into #tmp_billpaytbz
                from #tmp_billhdrtb bh (nolock)
                inner join billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
                where bp.TendCode = 'CHG'

                select bh.shopcode,bh.entdate,bh.TerminalNo,bh.BillNo,bh.tendtype,bh.tendcode,bh.cardname
                ,sum(case when bh.tendcode+bh.Tendtype = 'CSHCSH' then bh.tendamt - bp.tendamt else bh.tendamt end) as tendamt into #tmp_billpaytb
                from #tmp_billpaytbx bh (nolock)
                left join #tmp_billpaytbz bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
                group by bh.shopcode,bh.entdate,bh.TerminalNo,bh.BillNo,bh.tendtype,bh.tendcode,bh.cardname

                select td.ShopCode,td.EntDate,td.TerminalNo,td.BillNo,i.catcode0,sum(bd.NetAmt) as NetAmt
                ,sum(case when bd.itemcode = bd.subcode then bd.ActQTY else 0 end) as Qty into #tmp_tenderx 
                from #tmp_billhdrtb td (nolock)
                inner join BillDtlTB bd (nolock) on td.shopcode = bd.ShopCode and td.EntDate = bd.EntDate and td.TerminalNo = bd.TerminalNo and td.BillNo = bd.BillNo
                inner join itmmastb i (nolock) on i.itemcode = bd.subcode  
                group by td.ShopCode,td.EntDate,td.TerminalNo,td.BillNo,i.catcode0

                select bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo,sum(bh.qty) as qty,bp.tendtype,bp.tendcode,bp.cardname,bp.TendAmt 
                ,row_number() OVER(partition BY bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo order by bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo) AS Row  into #tmp_tender 
                from #tmp_tenderx bh (nolock)
                left outer join #tmp_billpaytb bp (nolock) on bp.shopcode = bh.ShopCode and bp.EntDate = bh.EntDate and bp.TerminalNo = bh.TerminalNo and bp.BillNo = bh.BillNo
                group by bh.ShopCode,bh.EntDate,bh.TerminalNo,bh.BillNo,bp.tendtype,bp.tendcode,bp.cardname,bp.TendAmt

                SELECT Mode,isnull(SUM(x.[Bill Count]),0) AS [Bill Count],  isnull(sum(x.[Cust Count]),0) as [Cust Count],isnull(sum(x.Qty),0) as Qty,isnull(sum(x.[Gross Sales]),0) as [Gross Sales]
                    ,isnull(sum(x.[Discount]),0) as [Discount],isnull(sum(x.[Base Sales]),0) as [Base Sales],isnull(sum(x.Vat),0) as Vat,isnull(sum(x.[Net Sales]),0) as [Net Sales]
                    ,isnull(sum(x.[Service Charge]),0) as [Service Charge],isnull(sum(x.[Base Service Charge]),0) as [Base Service Charge],isnull(sum(x.[Vat Service Charge]),0) as [Vat Service Charge]
                    ,isnull(sum(x.[Net Total]),0) as [Net Total] ,ISNULL(SUM(x.[CASH]),0) AS [CASH],ISNULL(SUM(x.[TENDER1]),0) AS [TENDER1],ISNULL(SUM(x.[TENDER2]),0) AS [TENDER2],ISNULL(SUM(x.[TENDER3]),0) AS [TENDER3],ISNULL(SUM(x.[TENDER4]),0) AS [TENDER4],ISNULL(SUM(x.[TENDER6]),0) AS [TENDER6],ISNULL(SUM(x.[TENDER7]),0) AS [TENDER7],ISNULL(SUM(x.[TENDER8]),0) AS [TENDER8],ISNULL(SUM(x.[TENDER9]),0) AS [TENDER9],ISNULL(SUM(x.[TENDER10]),0) AS [TENDER10],ISNULL(SUM(x.[TENDER11]),0) AS [TENDER11],ISNULL(SUM(x.[TENDER12]),0) AS [TENDER12],ISNULL(SUM(x.[TENDER13]),0) AS [TENDER13],ISNULL(SUM(x.[TENDER14]),0) AS [TENDER14],ISNULL(SUM(x.[TENDER15]),0) AS [TENDER15],ISNULL(SUM(x.[TENDER001]),0) AS [TENDER001],ISNULL(SUM(x.[TENDER002]),0) AS [TENDER002],ISNULL(SUM(x.[TENDER003]),0) AS [TENDER003],ISNULL(SUM(x.[TENDER004]),0) AS [TENDER004],ISNULL(SUM(x.[TENDER005]),0) AS [TENDER005],ISNULL(SUM(x.[TENDER006]),0) AS [TENDER006],ISNULL(SUM(x.[TENDER007]),0) AS [TENDER007],ISNULL(SUM(x.[TENDER008]),0) AS [TENDER008],ISNULL(SUM(x.[TENDER009]),0) AS [TENDER009],ISNULL(SUM(x.[TENDER0010]),0) AS [TENDER0010],ISNULL(SUM(x.[TENDER0011]),0) AS [TENDER0011],ISNULL(SUM(x.[TENDER0012]),0) AS [TENDER0012],ISNULL(SUM(x.[TENDER0013]),0) AS [TENDER0013],ISNULL(SUM(x.[TENDER0014]),0) AS [TENDER0014],ISNULL(SUM(x.[TENDER0015]),0) AS [TENDER0015],ISNULL(SUM(x.[TENDER0016]),0) AS [TENDER0016],ISNULL(SUM(x.[TENDER0017]),0) AS [TENDER0017],ISNULL(SUM(x.[TENDER0018]),0) AS [TENDER0018],ISNULL(SUM(x.[TENDER0019]),0) AS [TENDER0019],ISNULL(SUM(x.[TENDER0020]),0) AS [TENDER0020],ISNULL(SUM(x.[TENDER0021]),0) AS [TENDER0021],ISNULL(SUM(x.[TENDER0022]),0) AS [TENDER0022],ISNULL(SUM(x.[TENDER0023]),0) AS [TENDER0023],ISNULL(SUM(x.[TENDER0024]),0) AS [TENDER0024],ISNULL(SUM(x.[TENDER0025]),0) AS [TENDER0025],ISNULL(SUM(x.[TENDER0026]),0) AS [TENDER0026],ISNULL(SUM(x.[TENDER0027]),0) AS [TENDER0027],isnull(sum(x.totalpay),0) AS [Total Payment],isnull(sum(x.TotalOCR),0) AS [Total OCR]
                    FROM (SELECT pm.modedes1 as Mode,SUM(case when td.row = 1 then 1 else 0 end) as [Bill Count],
                    sum(case when td.row = 1 then bh.noperson else 0 end) as [Cust Count],sum(case when td.row = 1 then td.Qty else 0 end) as Qty
                    ,SUM(case when td.row = 1 then bh.BillDisc + bh.MemDisc + bh.Voucher + bh.ItemDisc + bh.CoupDisc + bh.NetBAmt else 0 end) as [Gross Sales]
                    ,SUM(case when td.row = 1 then bh.BillDisc + bh.MemDisc + bh.Voucher + bh.ItemDisc + bh.CoupDisc else 0 end) as [Discount]
                    ,sum(case when p.vattype = '1' then
                    case when td.row = 1 then bh.NetBAmt else 0 end 
                    else case when td.row = 1 then (bh.NetBAmt - bh.VatAmt1 + bh.VatAmt2) else 0 end end) as [Base Sales] --P.Yu change 20/07/2022
                    ,sum(case when td.row = 1 then bh.VatAmt1 - bh.VatAmt2 else 0 end ) as Vat
                    ,sum(case when p.vattype = '1' then 
                    case when td.row = 1 then (bh.NetBAmt + bh.VatAmt1 - bh.VatAmt2)  else 0 end
                    else case when td.row = 1 then bh.NetBAmt  else 0 end end) as [Net Sales],
                    SUM(case when td.row = 1 then  round( bh.OthChrg + bh.VatAmt2 ,2)  else 0 end) as [Service Charge],
                    SUM(case when td.row = 1 then   bh.OthChrg  else 0 end) AS [Base Service Charge],
                    SUM(case when td.row = 1 then round(bh.VatAmt2,2) else 0 end) AS [Vat Service Charge],
                    ---
                    sum(case when p.vattype = '1' then
                    case when td.row = 1 then (bh.NetBAmt + bh.VatAmt1 + bh.OthChrg) else 0 end  
                    else case when td.row = 1 then (bh.NetBAmt + round(bh.OthChrg + bh.VatAmt2,2)) else 0 end end) as [Net Total],isnull((select sum(td.tendamt) where td.TendType <> 'OCR'),0) as TotalPay,
					                    isnull((select sum(td.tendamt) where td.TendType = 'OCR'),0) as TotalOCR,sum(td.TendAmt) as totalpay99,isnull((select sum(td.tendamt) where td.TendType + td.TendCode + td.CardName = 'CSHCSHCASH'),0) AS [CASH] ,isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRD1TRM'),0) AS [TENDER1],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRD3DOL'),0) AS [TENDER2],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRD4APY'),0) AS [TENDER3],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDALI'),0) AS [TENDER4],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDEFT'),0) AS [TENDER6],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDEPLM'),0) AS [TENDER7],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDFPD'),0) AS [TENDER8],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDGRP'),0) AS [TENDER9],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDRBH'),0) AS [TENDER10],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDSPF'),0) AS [TENDER11],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDT001'),0) AS [TENDER12],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDT002'),0) AS [TENDER13],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDT005'),0) AS [TENDER14],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'CRDT006'),0) AS [TENDER15],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0011'),0) AS [TENDER001],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0012'),0) AS [TENDER002],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0013'),0) AS [TENDER003],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0029'),0) AS [TENDER004],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0041'),0) AS [TENDER005],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0042'),0) AS [TENDER006],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0043'),0) AS [TENDER007],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0044'),0) AS [TENDER008],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0045'),0) AS [TENDER009],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0059'),0) AS [TENDER0010],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0067'),0) AS [TENDER0011],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0068'),0) AS [TENDER0012],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0069'),0) AS [TENDER0013],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0070'),0) AS [TENDER0014],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0071'),0) AS [TENDER0015],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0072'),0) AS [TENDER0016],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0073'),0) AS [TENDER0017],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0074'),0) AS [TENDER0018],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0075'),0) AS [TENDER0019],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0076'),0) AS [TENDER0020],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0077'),0) AS [TENDER0021],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0078'),0) AS [TENDER0022],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0079'),0) AS [TENDER0023],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0080'),0) AS [TENDER0024],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0081'),0) AS [TENDER0025],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0082'),0) AS [TENDER0026],isnull((select sum(td.tendamt) where td.TendType + td.TendCode = 'VC1VC0083'),0) AS [TENDER0027] from #tmp_tender td (nolock)
                    inner join #tmp_billhdrtb bh (nolock) on td.shopcode = bh.ShopCode and td.EntDate = bh.EntDate and td.TerminalNo = bh.TerminalNo and td.BillNo = bh.BillNo
                    inner join posshoptb p (nolock) on p.ShopCode = bh.ShopCode
                    inner join PosBrnTB brn (nolock) on brn.BrandCode = p.BrandCode
                    inner join prcmodtb pm (nolock) on pm.pricemode = bh.pricemode 
                     GROUP BY pm.modedes1,p.VatType ,td.TendType,td.TendCode,td.CardName,td.shopcode,td.entdate,td.terminalno,td.billno
                    ) x

                     GROUP BY Mode 

                    

                    drop table #tmp_tenderx; drop table #tmp_tender; drop table #tmp_billhdrtb; drop table #tmp_billpaytbx; drop table #tmp_billpaytbz; drop table #tmp_billpaytb; 