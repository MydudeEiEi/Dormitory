--Waste Report
SELECT b.EntDate,CONVERT(VARCHAR(20),b.EntDate,100) AS [Date Period],b.WasteNo AS BillNo,isnull(r.RsonDes1,isnull(substring(bh.rsoncode,CHARINDEX('|',bh.RsonCode) + 1,len(bh.rsoncode) - CHARINDEX('|',bh.RsonCode)),'')) AS Reason,
u.usrName1 AS Staff,b.SubCode AS setItemCode,i.ItemDes1 AS setItemName,sum(b.WASTEQTY) AS [Waste Qty]

FROM PosShopTB p (NOLOCK)

INNER JOIN WasteHdrTB bh (NOLOCK) ON p.ShopCode = bh.ShopCode
INNER JOIN (

	select b.ShopCode,b.TerminalNo,b.EntDate,b.WasteDate,b.WasteType,b.WasteNo,b.SubCode,b.ItemCode,b.[sequence],
	sum(b.wasteqty) as WASTEQTY
	from WasteDtlTB b (nolock)
	where  (b.TerminalNo BETWEEN '01' AND '99') AND (b.EntDate BETWEEN '2022-08-01' AND '2022-08-07') 
	group by b.ShopCode,b.TerminalNo,b.EntDate,b.WasteDate,b.WasteType,b.WasteNo,b.SubCode,b.ItemCode,b.[sequence] 

) b  ON bh.ShopCode = b.ShopCode AND bh.TerminalNo = b.TerminalNo AND bh.EntDate = b.EntDate AND bh.WasteType = b.WasteType AND bh.WasteNo = b.WasteNo
INNER JOIN ItmMasTB i (NOLOCK) ON b.SubCode = i.ItemCode 
LEFT JOIN tbuser u (NOLOCK) ON bh.StaffCode = u.usrCode
LEFT JOIN PosRsnTB r (NOLOCK) ON bh.RsonCode = r.RsonCode 

WHERE (b.ShopCode BETWEEN '9999' AND 'XXXX') AND (b.TerminalNo BETWEEN '01' AND '99') AND (b.EntDate BETWEEN '2022-08-01' AND '2022-08-07') AND (LEFT(bh.WasteTime,5) BETWEEN '00:00' AND '23:59')  
GROUP BY b.EntDate,b.WasteNo,r.RsonDes1,bh.rsoncode,u.usrName1,i.StndCost,b.SubCode,i.ItemDes1,i.StndCost  
ORDER BY b.EntDate,b.WasteNo,b.SubCode,i.ItemDes1 